
const Mode={
	base:'基础模式',
	love:'恋爱模式',
	height:'高级模式',
	hot:'热情模式',
	violent:'猛烈模式'
}
export default Mode