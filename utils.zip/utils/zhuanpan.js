const base=['喝酒一杯','下家喝一杯','亲一个女生的手','坐对方腿上',]
const love=['亲吻对方的脸','拥抱对方','亲对方的手','手放在对方肚子上',]
const height=['喝酒一杯','下家喝一杯','亲一个女生的手','做对方腿上',]
const hot=['喝酒一杯','下家喝一杯','亲一个女生的手','做对方腿上',]
const violent=['喝酒一杯','下家喝一杯','亲一个女生的手','做对方腿上',]
	
const zhuanpan_Data={
	base,love,height,hot,violent
}
export default zhuanpan_Data